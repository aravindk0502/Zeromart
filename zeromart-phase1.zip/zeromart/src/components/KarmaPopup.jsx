import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function KarmaPopup() {
  const { karmaPopup, closeKarmaPopup } = useApp();
  const [given, setGiven] = useState(false);
  const [note, setNote] = useState('');

  if (!karmaPopup) return null;

  function handleGive() {
    setGiven(true);
    setTimeout(() => {
      closeKarmaPopup();
      setGiven(false);
      setNote('');
    }, 1600);
  }

  return (
    <div className="sheet-center">
      <div className="modal" style={{ textAlign: 'center' }}>
        {given ? (
          <div style={{ padding: '24px 0' }}>
            <div style={{ fontSize: 56, marginBottom: 12, animation: 'popIn 0.4s ease' }}>⭐</div>
            <div style={{ fontSize: 20, fontWeight: 700, fontFamily: 'Sora, sans-serif', color: 'var(--zm-amber)', marginBottom: 6 }}>+1 Karma given!</div>
            <div style={{ fontSize: 14, color: 'var(--zm-text-muted)' }}>You made {karmaPopup.name}'s day 🌟</div>
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 64, height: 64, borderRadius: '50%', background: 'var(--zm-amber-soft)', border: '2px solid var(--zm-amber)', margin: '0 auto 16px', fontWeight: 700, fontSize: 24, color: 'var(--zm-accent)' }}>
              {karmaPopup.initials}
            </div>

            <div style={{ fontSize: 11, color: 'var(--zm-text-dim)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6 }}>
              Item received from
            </div>
            <div style={{ fontSize: 20, fontWeight: 700, fontFamily: 'Sora, sans-serif', marginBottom: 4 }}>{karmaPopup.name}</div>
            <div style={{ fontSize: 13, color: 'var(--zm-text-muted)', marginBottom: 20 }}>
              Give them 1 karma point for this transaction
            </div>

            <div style={{ display: 'flex', justifyContent: 'center', gap: 4, marginBottom: 20 }}>
              {[1, 2, 3, 4, 5].map(i => (
                <Star key={i} size={28} color="var(--zm-amber)" fill="var(--zm-amber)" />
              ))}
            </div>

            <input
              className="input"
              placeholder="Add a note (optional) — Great condition, very helpful…"
              value={note}
              onChange={e => setNote(e.target.value)}
              style={{ marginBottom: 14, fontSize: 13 }}
            />

            <button className="btn btn-primary btn-full" onClick={handleGive} style={{ marginBottom: 10, fontSize: 15, padding: '14px' }}>
              <Star size={16} fill="white" />
              Give +1 Karma
            </button>

            <div style={{ fontSize: 11, color: 'var(--zm-text-dim)' }}>
              This is required to complete the transaction
            </div>
          </>
        )}
      </div>
    </div>
  );
}
