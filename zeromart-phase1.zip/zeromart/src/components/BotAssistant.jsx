import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

const SUGGESTIONS = ['How to sell?', 'How does karma work?', 'What is ₹29 for?', 'In-person collect?'];

export default function BotAssistant() {
  const { botOpen, setBotOpen, getBotAnswer } = useApp();
  const [messages, setMessages] = useState([
    { id: 0, from: 'bot', text: "Hi! I'm ZeroBot 🤖 — I can only answer questions about ZeroMart. What would you like to know?" }
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing]);

  function ask(q) {
    const question = q || input.trim();
    if (!question) return;
    setInput('');
    setMessages(prev => [...prev, { id: Date.now(), from: 'user', text: question }]);
    setTyping(true);
    setTimeout(() => {
      const answer = getBotAnswer(question);
      setMessages(prev => [...prev, { id: Date.now() + 1, from: 'bot', text: answer }]);
      setTyping(false);
    }, 700);
  }

  if (!botOpen) return null;

  return (
    <div className="overlay">
      <div className="sheet" style={{ height: '65vh', display: 'flex', flexDirection: 'column', padding: 0 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px', borderBottom: '1px solid var(--zm-border)', flexShrink: 0 }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--zm-accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Bot size={18} color="var(--zm-accent)" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 600 }}>ZeroBot</div>
            <div style={{ fontSize: 11, color: 'var(--zm-text-dim)' }}>Only answers ZeroMart questions</div>
          </div>
          <button onClick={() => setBotOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--zm-text-muted)' }}>
            <X size={18} />
          </button>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
          {messages.map(msg => (
            <div key={msg.id} style={{ display: 'flex', justifyContent: msg.from === 'user' ? 'flex-end' : 'flex-start', gap: 8, alignItems: 'flex-end' }}>
              {msg.from === 'bot' && (
                <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--zm-accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Bot size={12} color="var(--zm-accent)" />
                </div>
              )}
              <div className={`chat-bubble ${msg.from === 'user' ? 'mine' : 'theirs'}`} style={{ fontSize: 13 }}>
                {msg.text}
              </div>
            </div>
          ))}
          {typing && (
            <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
              <div style={{ width: 24, height: 24, borderRadius: '50%', background: 'var(--zm-accent-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Bot size={12} color="var(--zm-accent)" />
              </div>
              <div className="chat-bubble theirs" style={{ fontSize: 13 }}>
                <span style={{ color: 'var(--zm-text-dim)' }}>Thinking…</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Suggestions */}
        <div style={{ display: 'flex', gap: 6, padding: '8px 16px', overflowX: 'auto', scrollbarWidth: 'none', flexShrink: 0, borderTop: '1px solid var(--zm-border)' }}>
          {SUGGESTIONS.map(s => (
            <button key={s} onClick={() => ask(s)} style={{ flexShrink: 0, padding: '5px 12px', borderRadius: 999, border: '1px solid var(--zm-border)', background: 'transparent', color: 'var(--zm-text-muted)', fontSize: 12, cursor: 'pointer', fontFamily: 'Inter, sans-serif', whiteSpace: 'nowrap' }}>
              {s}
            </button>
          ))}
        </div>

        {/* Input */}
        <div style={{ display: 'flex', gap: 8, padding: '10px 12px 14px', flexShrink: 0 }}>
          <input
            className="input"
            style={{ flex: 1, fontSize: 13 }}
            placeholder="Ask about ZeroMart…"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && ask()}
          />
          <button onClick={() => ask()} className="btn btn-primary" style={{ padding: '0 14px', borderRadius: 10 }}>
            <Send size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}
