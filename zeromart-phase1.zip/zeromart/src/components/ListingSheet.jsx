import React, { useState, useRef } from 'react';
import { X, Camera, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function ListingSheet() {
  const { listingSheet, setListingSheet } = useApp();
  const [step, setStep] = useState(1);
  const [photo, setPhoto] = useState(null);
  const [desc, setDesc] = useState('');
  const [posted, setPosted] = useState(false);
  const fileRef = useRef(null);

  if (!listingSheet) return null;

  function handlePhoto(e) {
    const file = e.target.files[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setPhoto(url);
      setStep(2);
    }
  }

  function post() {
    setPosted(true);
    setTimeout(() => {
      setListingSheet(false);
      setStep(1);
      setPhoto(null);
      setDesc('');
      setPosted(false);
    }, 2000);
  }

  return (
    <div className="overlay">
      <div className="sheet">
        {/* Handle */}
        <div style={{ width: 40, height: 4, borderRadius: 999, background: 'var(--zm-border)', margin: '0 auto 16px' }} />

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, fontFamily: 'Sora, sans-serif' }}>List for free</div>
            <div style={{ fontSize: 12, color: 'var(--zm-text-dim)' }}>Photo + description — that's it</div>
          </div>
          <button onClick={() => setListingSheet(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--zm-text-muted)' }}>
            <X size={20} />
          </button>
        </div>

        {posted ? (
          <div style={{ textAlign: 'center', padding: '32px 0' }}>
            <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--zm-green-soft)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <Check size={32} color="var(--zm-green)" />
            </div>
            <div style={{ fontSize: 20, fontWeight: 700, fontFamily: 'Sora, sans-serif', marginBottom: 6 }}>Listed! 🎉</div>
            <div style={{ fontSize: 13, color: 'var(--zm-text-muted)' }}>Your item is now live. Nearby buyers will be notified.</div>
          </div>
        ) : (
          <>
            {/* Photo section */}
            <div
              onClick={() => fileRef.current?.click()}
              style={{ height: 180, borderRadius: 16, border: `2px dashed ${photo ? 'var(--zm-accent)' : 'var(--zm-border)'}`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', marginBottom: 16, overflow: 'hidden', position: 'relative', background: photo ? 'transparent' : 'var(--zm-surface2)' }}
            >
              {photo ? (
                <img src={photo} alt="Product" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <>
                  <Camera size={32} color="var(--zm-text-dim)" style={{ marginBottom: 8 }} />
                  <span style={{ fontSize: 14, color: 'var(--zm-text-muted)' }}>Tap to take or upload a photo</span>
                  <span style={{ fontSize: 12, color: 'var(--zm-text-dim)', marginTop: 4 }}>Required</span>
                </>
              )}
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhoto} />

            {/* Description */}
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 13, color: 'var(--zm-text-muted)', display: 'block', marginBottom: 6 }}>Description <span style={{ color: 'var(--zm-text-dim)' }}>(optional)</span></label>
              <textarea
                className="input textarea"
                placeholder="What is it? Condition? Any details that help…"
                value={desc}
                onChange={e => setDesc(e.target.value)}
              />
            </div>

            {/* Price always zero */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--zm-surface2)', borderRadius: 12, padding: '12px 16px', marginBottom: 16 }}>
              <span style={{ fontSize: 13, color: 'var(--zm-text-muted)' }}>Listing price</span>
              <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--zm-green)' }}>₹0 — FREE</span>
            </div>

            <button
              className="btn btn-primary btn-full"
              style={{ fontSize: 15, padding: '14px' }}
              onClick={post}
              disabled={!photo}
            >
              {!photo ? 'Add a photo to continue' : 'Post listing — it\'s free'}
            </button>

            {!photo && (
              <div style={{ textAlign: 'center', marginTop: 10, fontSize: 12, color: 'var(--zm-text-dim)' }}>
                A photo helps buyers trust your listing
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
