import React from 'react';
import './index.css';
import { AppProvider, useApp } from './context/AppContext';
import HomePage from './pages/HomePage';
import SellerPage from './pages/SellerPage';
import ProfilePage from './pages/ProfilePage';
import NotificationsPage from './pages/NotificationsPage';
import ProductSheet from './components/ProductSheet';
import KarmaPopup from './components/KarmaPopup';
import TempChat from './components/TempChat';
import BotAssistant from './components/BotAssistant';
import ListingSheet from './components/ListingSheet';
import BuyerPaySheet from './components/BuyerPaySheet';
import CollectRequestHandler from './components/CollectRequestHandler';
import { Home, Tag, User, Bell, Plus, Bot } from 'lucide-react';

function Shell() {
  const {
    page, setPage,
    user, switchMode,
    selectedProduct,
    karmaPopup,
    chatOpen,
    botOpen, setBotOpen,
    listingSheet, setListingSheet,
    buyerPaySheet,
    collectRequest,
    notifications,
  } = useApp();

  const unread = notifications.filter(n => !n.read).length;

  const navItems = [
    { key: 'home', icon: <Home size={20} />, label: 'Home' },
    { key: 'sell', icon: <Tag size={20} />, label: 'Sell' },
    { key: 'list', icon: <Plus size={22} />, label: 'List', special: true },
    { key: 'notifications', icon: <Bell size={20} />, label: 'Alerts', badge: unread },
    { key: 'profile', icon: <User size={20} />, label: 'Profile' },
  ];

  function handleNav(key) {
    if (key === 'list') {
      setListingSheet(true);
      return;
    }
    setPage(key);
  }

  return (
    <div className="app-shell">
      {/* Page content */}
      {page === 'home' && <HomePage />}
      {page === 'sell' && <SellerPage />}
      {page === 'profile' && <ProfilePage />}
      {page === 'notifications' && <NotificationsPage />}

      {/* Bottom nav */}
      <nav className="bottom-nav">
        {navItems.map(item => (
          <button
            key={item.key}
            className={`nav-item ${page === item.key && item.key !== 'list' ? 'active' : ''}`}
            onClick={() => handleNav(item.key)}
            style={item.special ? {
              background: 'var(--zm-accent)',
              color: 'white',
              width: 48,
              height: 48,
              borderRadius: '50%',
              padding: 0,
              boxShadow: '0 4px 16px rgba(124,92,252,0.4)',
            } : {}}
          >
            <div style={{ position: 'relative' }}>
              {item.icon}
              {item.badge > 0 && (
                <div style={{ position: 'absolute', top: -4, right: -4, width: 8, height: 8, borderRadius: '50%', background: 'var(--zm-accent)', border: '1.5px solid var(--zm-bg)' }} />
              )}
            </div>
            {!item.special && <span>{item.label}</span>}
          </button>
        ))}
      </nav>

      {/* Bot button */}
      <button className="bot-btn" onClick={() => setBotOpen(true)} title="Ask ZeroBot">
        <Bot size={22} color="white" />
      </button>

      {/* Overlays */}
      {selectedProduct && <ProductSheet />}
      {karmaPopup && <KarmaPopup />}
      {chatOpen && <TempChat />}
      {botOpen && <BotAssistant />}
      {listingSheet && <ListingSheet />}
      {buyerPaySheet && <BuyerPaySheet />}
      {collectRequest && <CollectRequestHandler />}
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  );
}
