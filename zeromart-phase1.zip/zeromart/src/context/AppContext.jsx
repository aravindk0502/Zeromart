import React, { createContext, useContext, useState, useCallback } from 'react';

const AppContext = createContext(null);

export const MOCK_PRODUCTS = [
  { id: 1, title: 'Sony Bluetooth Speaker', category: 'Electronics', emoji: '🔊', distance: 0.4, condition: 'Good', seller: { name: 'Ravi K', karma: 47, initials: 'RK' }, description: 'Used for 6 months, works perfectly. Moving abroad, no use for it.', nearbyEligible: true, listed: '2 hours ago' },
  { id: 2, title: 'Wooden Study Table', category: 'Furniture', emoji: '🪑', distance: 1.2, condition: 'Very Good', seller: { name: 'Priya M', karma: 83, initials: 'PM' }, description: 'Solid teak wood. Kids outgrew it. Ideal for 8–14 year olds.', nearbyEligible: false, listed: '5 hours ago' },
  { id: 3, title: 'Baby Stroller', category: 'Baby & Kids', emoji: '🍼', distance: 0.7, condition: 'Like New', seller: { name: 'Ananya R', karma: 29, initials: 'AR' }, description: 'Used only 3 months. Baby preferred to be carried! Perfect condition.', nearbyEligible: true, listed: '1 day ago' },
  { id: 4, title: 'Yoga Mat', category: 'Sports', emoji: '🧘', distance: 2.1, condition: 'Good', seller: { name: 'Karthik S', karma: 62, initials: 'KS' }, description: '6mm thick mat, washed and clean. Bought a premium one, giving this away.', nearbyEligible: false, listed: '3 hours ago' },
  { id: 5, title: 'Stack of Engineering Books', category: 'Books', emoji: '📚', distance: 0.3, condition: 'Good', seller: { name: 'Meera V', karma: 115, initials: 'MV' }, description: 'GATE prep books, Anna University syllabus. Take all 12 books.', nearbyEligible: true, listed: '6 hours ago' },
  { id: 6, title: 'Air Fryer', category: 'Appliances', emoji: '🍳', distance: 1.8, condition: 'Very Good', seller: { name: 'Suresh P', karma: 38, initials: 'SP' }, description: 'Upgraded to a bigger one. 2.5L capacity, works great.', nearbyEligible: false, listed: '2 days ago' },
  { id: 7, title: 'Kids Bicycle', category: 'Sports', emoji: '🚲', distance: 0.6, condition: 'Good', seller: { name: 'Lakshmi T', karma: 74, initials: 'LT' }, description: '14 inch wheels, suitable for 5–8 year olds. Slightly scratched but fully functional.', nearbyEligible: true, listed: '4 hours ago' },
  { id: 8, title: 'Formal Shirts (5 pcs)', category: 'Clothing', emoji: '👔', distance: 3.0, condition: 'Very Good', seller: { name: 'Vikram B', karma: 21, initials: 'VB' }, description: 'Size 40, wore each maybe 3–4 times. Moving to startup life!', nearbyEligible: false, listed: '1 hour ago' },
];

export const CATEGORIES = ['All', 'Electronics', 'Furniture', 'Baby & Kids', 'Sports', 'Books', 'Appliances', 'Clothing'];

const PLATFORM_ANSWERS = {
  'how to sell': 'Tap the + button at the bottom to list a product. Take a photo, add a short description, and it goes live instantly — completely free!',
  'how to buy': 'Pay a one-time ₹29 to unlock buyer access forever. Then browse, search, and request any item you like.',
  'delivery': 'The buyer pays the actual delivery cost. We work with Shadowfax and Porter. Prices are shown before you confirm.',
  'karma': 'Karma points are given by buyers after receiving an item. Higher karma = more visibility and better rewards. You earn 1 karma per successful transaction.',
  'in person': 'If a seller is within 1 km of you, you can request to collect in person. If the seller accepts, a temporary chat opens to coordinate.',
  'free': 'Yes! Listing on ZeroMart is completely free for sellers. Items are listed at ₹0.',
  'reward': 'Sellers earn delivery credits and unlock vouchers from brands like Swiggy and BookMyShow when they hit karma milestones.',
  'account': 'One account can switch between Seller and Buyer mode anytime. Buyer mode requires a one-time ₹29 fee.',
  '29': 'The ₹29 is a one-time lifetime fee to unlock buyer access. Pay once, browse and buy forever.',
  'chat': 'A temporary chat opens between buyer and seller only when the seller accepts an in-person collection request. It disappears once the handoff is complete.',
  'report': 'Tap the flag icon on any listing or profile to report. Three verified reports trigger a review. Serious fraud leads to permanent ban.',
  'voucher': 'Hit karma milestones (5, 10, 25 items given) to unlock real vouchers from partner brands.',
  'credits': 'Delivery credits are earned every time you successfully give away an item. Use them to offset your own delivery costs when buying.',
};

export function AppProvider({ children }) {
  const [page, setPage] = useState('home');
  const [user, setUser] = useState({ name: 'Aravindan', initials: 'AK', mode: 'seller', isBuyer: false, karma: 12, credits: 3, vouchers: 1 });
  const [products] = useState(MOCK_PRODUCTS);
  const [favourites, setFavourites] = useState([3, 5]);
  const [karmaPopup, setKarmaPopup] = useState(null);
  const [chatOpen, setChatOpen] = useState(null);
  const [botOpen, setBotOpen] = useState(false);
  const [notifications, setNotifications] = useState([
    { id: 1, text: 'Meera V listed new books nearby!', time: '5m ago', read: false },
    { id: 2, text: 'You received a karma point from Raj S', time: '2h ago', read: false },
    { id: 3, text: 'Your stroller request was accepted', time: '1d ago', read: true },
  ]);
  const [listingSheet, setListingSheet] = useState(false);
  const [buyerPaySheet, setBuyerPaySheet] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [collectRequest, setCollectRequest] = useState(null);

  const toggleFavourite = useCallback((id) => {
    setFavourites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  }, []);

  const triggerKarmaPopup = useCallback((seller) => {
    setKarmaPopup(seller);
  }, []);

  const closeKarmaPopup = useCallback(() => {
    setKarmaPopup(null);
    setUser(prev => ({ ...prev, karma: prev.karma + 1 }));
  }, []);

  const switchMode = useCallback(() => {
    if (user.mode === 'seller' && !user.isBuyer) {
      setBuyerPaySheet(true);
    } else {
      setUser(prev => ({ ...prev, mode: prev.mode === 'seller' ? 'buyer' : 'seller' }));
    }
  }, [user]);

  const completeBuyerPayment = useCallback(() => {
    setUser(prev => ({ ...prev, isBuyer: true, mode: 'buyer' }));
    setBuyerPaySheet(false);
  }, []);

  const getBotAnswer = useCallback((question) => {
    const q = question.toLowerCase();
    for (const [key, answer] of Object.entries(PLATFORM_ANSWERS)) {
      if (q.includes(key)) return answer;
    }
    return "I can help you with: selling, buying, delivery, karma, in-person collection, rewards, and account info. Try asking about any of these!";
  }, []);

  const markNotificationsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  return (
    <AppContext.Provider value={{
      page, setPage,
      user, setUser,
      products,
      favourites, toggleFavourite,
      karmaPopup, triggerKarmaPopup, closeKarmaPopup,
      chatOpen, setChatOpen,
      botOpen, setBotOpen,
      notifications, markNotificationsRead,
      listingSheet, setListingSheet,
      buyerPaySheet, setBuyerPaySheet,
      selectedProduct, setSelectedProduct,
      collectRequest, setCollectRequest,
      switchMode, completeBuyerPayment,
      getBotAnswer,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
